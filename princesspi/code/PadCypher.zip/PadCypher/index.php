<?php
$title = 'Pad Cypher Encryption System';
$body = <<<EOT
<ul>
 <li><a href="encrypt.php">Encrypt a Message</a></li>
 <li><a href="decrypt.php">Decrypt a Message</a></li>
 <li><a href="generate.php">Generate a Pad</a></li>
</ul>
EOT;
include('template.php');
?>