<?php
$value = '0123456789';
if($value[10] == null) { echo 'null'; }
?>