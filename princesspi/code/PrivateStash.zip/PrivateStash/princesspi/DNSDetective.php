<html>
<head>
<title>Princess Pi's DNS Detective!</title>
<style type="text/css">
body {
    font-family: Georgia,Palatino,serif;
    background-color: #FFDDDD;
}

h1.title {
    color: purple;
	font-size: 3em;
}

img { border: 0; }

.hidden { display: none; }

input[type=text],textarea { 
    border: 2px solid purple;
    background-color: #FFEEEE;
}

input[type=text]:focus,textarea:focus {
    border: 2px solid pink;
}

select {
    border: 2px solid purple;
    background-color: #FFEEEE;
}

select:focus {
    border: 2px solid pink;
}

input[type=button],input[type=file],input[type=submit] {
    border: 2px solid purple;
    background: #FFEEEE;
}

input[type=button]:hover,input[type=file]:hover,input[type=submit]:hover {
    background: #FFAAAA;
}
</style>
</head>
<body>
<h1 class="title">Princeess Pi's DNS Detective!</h1>
<p>Princess Pi is a great detective!  She always knows just where to look to get information on any domain!</p>
<form action="" method="post">
<label for="domain">Domain: </label> <input type="text" name="domain" id="domain"> <input type="submit" value="Get DNS Records">
</form>
<p><?php
if($_POST['domain']) {
$result = dns_get_record($_POST['domain'], DNS_ANY, $authns, $addtl);
echo "<pre>Result = ";
print_r($result);
echo "Auth NS = ";
print_r($authns);
echo "Additional = ";
print_r($addtl);
echo "</pre>";

$ports = [21,22,23,25,53,80,110,119,156,194,443,1080,2082,3306,546,547,8080];
$host = $_POST['domain'];
for($i=0;$i<count($ports);$i++) { 
$fp = fsockopen($host,$ports[$i],$errno,$errstr,1); 
if($fp) 
{ 
echo "port " . $ports[$i] . " open on " . $host . "<br>"; 
fclose($fp); 
} 

flush(); 
} //end for

}
?></p>
<p><img src="images/princesspismall.png"></p>
</body>
</html>